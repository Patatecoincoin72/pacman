"""
Programme réalisé par Dina, YASIN, 1G3
"""
import pygame, time
from pygame.locals import *

#variables du niveau
NB_TILES=48                                                                      #nombre de tiles a charger (ici de 00.png à 47.png) 48 au total !!
TITLE_SIZE=22                                                                    #definition du dessin (carré)
largeur=54                                                                       #hauteur du niveau
hauteur=31                                                                       #largeur du niveau
tiles=[]                                                                         #liste d'images tiles

#variables de gestion du pacman
pacX=26                                                                          #position x y
pacY=22
compteurBilles=0
direction='right'                                                                #direction initiale
vies=3

#variables de gestion du fantome
FRAMERATE_FANTOME=5                                                              #vitesse du fantome chiffre elevé=vitesse lente
NB_DEPLACEMENT_FANTOME=55                                                        #le fantome se deplace sur 54 cases
positionFantome=1
frameRateCounterFantome=0
posfX=13                                                                         #position initiale du fantome
posfY=1

#load sons
pygame.mixer.init()
musique=pygame.mixer.Sound('data/coincoin.wav')
coin=pygame.mixer.Sound('data/coin.wav')
quack=pygame.mixer.Sound('data/quack.wav')

clapping=pygame.mixer.Sound('data/clapping.wav')
yippee=pygame.mixer.Sound('data/yippee.wav')

boo=pygame.mixer.Sound('data/boo.wav')
beeps=pygame.mixer.Sound('data/negative_beeps.wav')

musique.play(loops=-1, maxtime=0, fade_ms=0)

#definition du niveau

niveau=[[ 1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 2, 1, 5, 5, 5, 5, 2, 1, 5, 5, 5, 5, 2, 1, 5, 5, 5, 5, 2, 1, 5, 5, 5, 5, 2, 1, 5, 5, 5, 5, 2, 1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 2],
        [ 6,18,18,18,18,18,18,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18,18,18,18,18,18,18, 6],
        [ 6,18, 1, 5, 5, 5, 5, 5, 5, 2,18, 6, 6,18, 1, 2,18, 6, 6,18, 1, 2,18, 6, 6,18, 1, 2,18, 6, 6,18, 1, 2,18, 6, 6,18, 1, 2,18, 6, 6,18, 1, 5, 5, 5, 5, 5, 5, 2,18, 6],
        [ 6,18, 6, 1, 5, 5, 5, 5, 2, 6,18, 6, 6,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 6, 6,18, 6, 1, 5, 5, 5, 5, 2, 6,18, 6],
        [ 6,18, 6, 6,18,18,18,18, 6, 6,18, 6, 6,18, 6, 6,18,18,18,18, 6, 6,19,18,18,18, 6, 6,18,18,18,19, 6, 6,18,18,18,18, 6, 6,18, 6, 6,18, 6, 6,18,18,18,18, 6, 6,18, 6],
        [ 6,18, 6, 6,18, 1, 2,18, 6, 6,18, 6, 6,18, 6, 6,18, 1, 2,18, 6, 3, 5, 5, 2,18, 6, 6,18, 1, 5, 5, 4, 6,18, 1, 2,18, 6, 6,18, 6, 6,18, 6, 6,18, 1, 2,18, 6, 6,18, 6],
        [ 6,18, 6, 6,18, 3, 4,18, 3, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 5, 5, 5, 4,18, 6, 6,18, 3, 5, 5, 5, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 4,18, 3, 4,18, 6, 6,18, 6],
        [ 6,18, 6, 6,18,18,18,19,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18,18,18,18, 6, 6,18,18,18,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18,18,18,19,18,18,18, 6, 6,18, 6],
        [ 6,18, 6, 3, 5, 5, 2,18, 1, 2,18, 6, 6,18, 1, 5, 5, 4, 6,18, 1, 5, 5, 5, 2,18, 6, 6,18, 1, 5, 5, 5, 2,18, 6, 3, 5, 5, 2,18, 6, 6,18, 1, 2,18, 1, 5, 5, 4, 6,18, 6],
        [ 6,18, 3, 5, 5, 5, 4,18, 3, 4,18, 3, 4,18, 3, 5, 5, 2, 6,18, 6, 1, 5, 5, 4, 0, 3, 4, 0, 3, 5, 5, 2, 6,18, 6, 1, 5, 5, 4,18, 3, 4,18, 3, 4,18, 3, 5, 5, 5, 4,18, 6],
        [ 6,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,19, 6, 6,18, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 6,18, 6, 6,19,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18, 6],
        [ 3, 5, 5, 5, 5, 5, 5, 5, 5, 2,18, 1, 2,18, 1, 2,18, 6, 6,18, 6, 6, 0, 1, 5,17,12,12,16, 5, 2, 0, 6, 6,18, 6, 6,18, 1, 2,18, 1, 2,18, 1, 5,5,  5, 5, 5, 5, 5, 5, 4],
        [ 1, 5, 5, 5, 5, 5, 5, 5, 2, 6,18, 6, 6,18, 3, 4,18, 3, 4,18, 3, 4, 0, 6, 0, 0, 0, 0, 0, 0, 6, 0, 3, 4,18, 3, 4,18, 3, 4,18, 6, 6,18, 6, 1, 5, 5, 5, 5, 5, 5, 5, 2],
        [ 6,18,18,18,18,18,18,18, 6, 6,18, 6, 6,18,18,18,18,18,18,18,18, 0, 0, 6, 0, 0, 0, 0, 0, 0, 6, 0, 0,18,18,18,18,18,18,18,18, 6, 6,18, 6, 6,18,18,18,18,18,18,18, 6],
        [ 6,18, 1, 5, 5, 5, 2,18, 6, 6,18, 6, 6,18, 1, 5, 5, 5, 5, 5, 5, 2, 0, 6, 0, 0, 0, 0, 0, 0, 6, 0, 1, 5, 5, 5, 5, 5, 5, 2,18, 6, 6,18, 6, 6,18, 1, 5, 5, 5, 2,18, 6],
        [ 6,18, 3, 5, 5, 5, 4,18, 3, 4,18, 6, 6,18, 3, 5, 5, 5, 5, 5, 5, 4, 0, 3, 5, 5, 5, 5, 5, 5, 4, 0, 3, 5, 5, 5, 5, 5, 5, 4,18, 6, 6,18, 3, 4,18, 3, 5, 5, 5, 4,18, 6],
        [ 6,18,18,18,18,18,18,18,18,18,18, 6, 6,18,18,18,18,18,18,18,18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,18,18,18,18,18,18,18,18, 6, 6,18,18,18,18,18,18,18,18,18,18, 6],
        [ 3, 5, 5, 5, 5, 5, 5, 5, 5, 2,18, 6, 6,18, 1, 2,18, 1, 2,18, 1, 5, 5, 5, 2, 0, 1, 2, 0, 1, 5, 5, 5, 2,18, 1, 2,18, 1, 2,18, 6, 6,18, 1, 5, 5, 5, 5, 5, 5, 5, 5, 4],
        [ 1, 5, 5, 5, 5, 5, 5, 5, 5, 4,18, 3, 4,18, 3, 4,18, 6, 6,18, 6, 1, 5, 5, 4,18, 6, 6,18, 3, 5, 5, 2, 6,18, 6, 6,18, 3, 4,18, 3, 4,18, 3, 5, 5, 5, 5, 5, 5, 5, 5, 2],
        [ 6,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,19, 6, 6,18, 6, 6,18,18,18,18, 6, 6,18,18,18,18, 6, 6,18, 6, 6,19,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18, 6],
        [ 6,18, 1, 5, 5, 5, 2,18, 1, 2,18, 1, 2,18, 1, 5, 5, 4, 6,18, 6, 6,18, 1, 5, 5, 4, 3, 5, 5, 2,18, 6, 6,18, 6, 3, 5, 5, 2,18, 1, 2,18, 1, 2,18, 1, 5, 5, 5, 2,18, 6],
        [ 6,18, 6, 1, 5, 5, 4,18, 3, 4,18, 6, 6,18, 3, 5, 5, 2, 6,18, 6, 6,18, 3, 5, 5, 5, 5, 5, 5, 4,18, 6, 6,18, 6, 1, 5, 5, 4,18, 6, 6,18, 3, 4,18, 3, 5, 5, 2, 6,18, 6],
        [ 6,18, 6, 6,18,18,18,19,18,18,18, 6, 6,18,18,18,18, 6, 6,18, 6, 6,18,18,18,18, 0,18,18,18,18,18, 6, 6,18, 6, 6,18,18,18,18, 6, 6,18,18,18,19,18,18,18, 6, 6,18, 6],
        [ 6,18, 6, 6,18, 1, 2,18, 1, 2,18, 6, 6,18, 1, 2,18, 6, 6,18, 6, 3, 5, 5, 2,18, 1, 2,18, 1, 5, 5, 4, 6,18, 6, 6,18, 1, 2,18, 6, 6,18, 1, 2,18, 1, 2,18, 6, 6,18, 6],
        [ 6,18, 6, 6,18, 3, 4,18, 6, 6,18, 6, 6,18, 6, 6,18, 3, 4,18, 3, 5, 5, 5, 4,18, 6, 6,18, 3, 5, 5, 5, 4,18, 3, 4,18, 6, 6,18, 6, 6,18, 6, 6,18, 3, 4,18, 6, 6,18, 6],
        [ 6,18, 6, 6,18,18,18,18, 6, 6,18, 6, 6,18, 6, 6,18,18,18,18,18,18,18,18,18,18, 6, 6,18,18,18,18,18,18,18,18,18,18, 6, 6,18, 6, 6,18, 6, 6,18,18,18,18, 6, 6,18, 6],
        [ 6,18, 6, 3, 5, 5, 5, 5, 4, 6,18, 6, 6,18, 6, 6,18, 1, 2,18, 1, 5, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 5, 2,18, 1, 2,18, 6, 6,18, 6, 6,18, 6, 3, 5, 5, 5, 5, 4, 6,18, 6],
        [ 6,18, 3, 5, 5, 5, 5, 5, 5, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4,18, 6, 6,18, 3, 4,18, 6, 6,18, 3, 5, 5, 5, 5, 5, 5, 4,18, 6],
        [ 6,18,18,18,18,18,18,18,18,18,18, 6, 6,19,18,18,18, 6, 6,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18, 6, 6,18,18,18,19, 6, 6,18,18,18,18,18,18,18,18,18,18, 6],
        [ 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 4, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 9],
        [ 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6]]

fantome=[[ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,54, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,53, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,52, 0, 0, 7, 8, 9,10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,51, 0, 0, 0, 0, 0,11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,50, 0, 0, 0, 0, 0,12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,49, 0, 0, 0, 0, 0,13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,48, 0, 0, 0, 0, 0,14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,47, 0, 0, 0, 0, 0,15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,43,44,45,46, 0, 0, 0, 0, 0,16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,42, 0, 0, 0, 0, 0, 0, 0, 0,17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,41, 0, 0, 0, 0, 0, 0, 0, 0,18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,40, 0, 0,25,24,23,22,21,20,19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,39, 0, 0,26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,38, 0, 0,27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,37, 0, 0,28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,36, 0, 0,29, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,35, 0, 0,30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,34,33,32,31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
         [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]


#la taille de la fenetre dépend de la largeur et de la hauteur du niveau
#on rajoute une rangée de 32 pixels en bas de la fentre pour afficher le score d'ou (hauteur +1)///Non
pygame.init()
fenetre=pygame.display.set_mode((largeur*TITLE_SIZE,hauteur*TITLE_SIZE))
pygame.display.set_caption("Pac-Man")
font=pygame.font.Font('freesansbold.ttf',20)

def variablesazero():                                                            #remets les variables du jeu à 0
    #variables de gestion du pacman
    pacX=26
    pacY=22
    compteurBilles=0
    direction='right'
    vies=3

    #variables de gestion du fantome
    FRAMERATE_FANTOME=5
    NB_DEPLACEMENT_FANTOME=55
    positionFantome=1
    frameRateCounterFantome=0
    posfX=13
    posfY=1


def main_menu():
    click=False
    while True:

        menu=pygame.image.load('data/menu.jpg')

        mx, my=pygame.mouse.get_pos()

        button_1=pygame.Rect(484, 271, 214, 105)
        button_2=pygame.Rect(445, 441, 305, 107)

        if button_1.collidepoint((mx, my)):
            if click:
                variablesazero()
                game()

        if button_2.collidepoint((mx, my)):
            if click:
                credits()

        pygame.draw.rect(fenetre, (255, 0, 0), button_1)
        pygame.draw.rect(fenetre, (255, 0, 0), button_2)
        fenetre.blit(menu, (0,0))

        click=False
        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
            if event.type==KEYDOWN:
                if event.key==K_ESCAPE:
                    pygame.quit()
            if event.type==MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True

        pygame.display.update()

def credits():
    running=True
    while running:

        mx, my=pygame.mouse.get_pos()

        button_3=pygame.Rect(8, 621, 225, 61)

        if button_3.collidepoint((mx, my)):
            if click:
                main_menu()

        pygame.draw.rect(fenetre, (255, 0, 0), button_3)
        credits=pygame.image.load('data/credits.jpg')
        fenetre.blit(credits, (0,0))

        click=False

        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
            if event.type==KEYDOWN:
                if event.key==K_ESCAPE:
                    pygame.quit()
            if event.type==MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True

        pygame.display.update()


def gameover():
    variablesazero()
    click=False
    running=True
    while running==True:

        mx, my=pygame.mouse.get_pos()

        button_4=pygame.Rect(0, 0, 1188, 682)

        if button_4.collidepoint((mx, my)):
            if click:
                boo.stop()
                beeps.stop()
                musique.play(loops=-1, maxtime=0, fade_ms=0)
                variablesazero()
                credits()

        pygame.draw.rect(fenetre, (255, 0, 0), button_4)
        gameover=pygame.image.load('data/gameover.jpg')
        fenetre.blit(gameover, (0,0))
        musique.stop()
        boo.play(loops=0, maxtime=0, fade_ms=0)
        beeps.play(loops=0, maxtime=0, fade_ms=0)


        click=False

        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
            if event.type==KEYDOWN:
                if event.key==K_ESCAPE:
                    pygame.quit()
            if event.type==MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True


        pygame.display.update()

def gagne():
    variablesazero()
    click=False
    running=True
    while running==True:

        mx, my=pygame.mouse.get_pos()

        button_5=pygame.Rect(0, 0, 1188, 682)

        if button_5.collidepoint((mx, my)):
            if click:
                yippee.stop()
                clapping.stop()
                musique.play(loops=-1, maxtime=0, fade_ms=0)
                credits()

        pygame.draw.rect(fenetre, (255, 0, 0), button_5)
        hurray=pygame.image.load('data/hurray.jpg')
        fenetre.blit(hurray, (0,0))
        musique.stop()
        yippee.play(loops=0, maxtime=0, fade_ms=0)
        clapping.play(loops=0, maxtime=0, fade_ms=0)


        click=False

        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
            if event.type==KEYDOWN:
                if event.key==K_ESCAPE:
                    pygame.quit()
            if event.type==MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True


        pygame.display.update()

def game():
    global pacX, pacY, compteurBilles, direction, vies, FRAMERATE_FANTOME, NB_DEPLACEMENT_FANTOME, positionFantome, frameRateCounterFantome, posfX, posfY

    def chargetiles(tiles):
        """
        fonction permettant de charger les images tiles dans une liste tiles[]
        """
        for n in range( 0,NB_TILES):
            #print('data/'+str(n)+'.png')
            tiles.append(pygame.image.load('data/'+str(n)+'.png'))               #attention au chemin


    def afficheNiveau(niveau):
        """
        affiche le niveau a partir de la liste a deux dimensions niveau[][]
        """
        for y in range(hauteur):
            for x in range(largeur):
                fenetre.blit(tiles[niveau[y][x]],(x*TITLE_SIZE,y*TITLE_SIZE))


    def affichePac():
        """
        Affiche le Pac-Man en position pacX et pacY avec animation bouche ouverte/fermée
        """

        if direction == 'up':

                # Efface l'écran
            effaceEcran()

                # bouche fermée
            fenetre.blit(tiles[40], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)                                                #délai entre les images

                # Efface l'écran
            effaceEcran()

                # bouche ouverte
            fenetre.blit(tiles[41], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)


        elif direction == 'down':

            effaceEcran()

            fenetre.blit(tiles[42], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)

            effaceEcran()

            fenetre.blit(tiles[43], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)


        elif direction == 'left':

            effaceEcran()

            fenetre.blit(tiles[44], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)

            effaceEcran()

            fenetre.blit(tiles[45], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)


        elif direction == 'right':

            effaceEcran()

            fenetre.blit(tiles[46], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)

            effaceEcran()

            fenetre.blit(tiles[47], (pacX * TITLE_SIZE, pacY * TITLE_SIZE))
            pygame.display.flip()
            pygame.time.delay(30)


    def afficheScoreEtVies(score,vies):
        """
        affiche le score et les vies
        """
        scoreAffiche=font.render("Score:",True,(0,255,0))
        scoreAfficher=font.render(str(score),True,(0,255,0))
        fenetre.blit(scoreAffiche,(20,660))
        fenetre.blit(scoreAfficher,(85,660))

        if vies==3:
            fenetre.blit(tiles[46], (1140, 655))
            fenetre.blit(tiles[46], (1100, 655))
            fenetre.blit(tiles[46], (1060, 655))
        elif vies==2:
            fenetre.blit(tiles[46], (1140, 655))
            fenetre.blit(tiles[46], (1100, 655))
        elif vies==1:
            fenetre.blit(tiles[46], (1140, 655))


    def rechercheFantome(fantome,position):                                      #recherche les coord du fantome dans la liste fantome
        """
        recherche les coordonnées du fantome en fonction du numéro de sa postion dans le parcours
        """
        print(position)                                                          #la position doit etre dans la liste fantome sinon plantage
        for y in range(hauteur):
            for x in range(largeur):
                if fantome[y][x]==position:
                    coodFantome=x,y
        return coodFantome                                                       #les coord du fantome x et y sont dans un tuple coodFantome

    def deplaceFantome(fantome):
        """
        Incrémente automatiquement le déplacement du fantome, gère sa vitesse et son affichage
        """
        global frameRateCounterFantome
        global positionFantome
        global posfX,posfY

        if frameRateCounterFantome==FRAMERATE_FANTOME:                           #ralenti la viteese du fantome
            posfX,posfY=rechercheFantome(fantome,positionFantome)                #deballage du tuple coordonnées du fantome
            positionFantome+=1
            if positionFantome==NB_DEPLACEMENT_FANTOME:                          #un tour est fait donc on passe à la 1ere position
                positionFantome=1
            frameRateCounterFantome=0                                            #compteur de vitesse à zero
        fenetre.blit(tiles[20],(posfX*TITLE_SIZE,posfY*TITLE_SIZE))              #affichage du fantome
        frameRateCounterFantome+=1                                               #incrémentation du compteur de vitesse

    def effaceEcran():
        fenetre.fill((255,202,209))
        afficheNiveau(niveau)
        deplaceFantome(fantome)
        afficheScoreEtVies(compteurBilles,vies)


    def touchFantome(pacX, pacY, posfX, posfY):
        if posfX==pacX and posfY==pacY:
            restartlevel()

    def restartlevel():
        posX=pacX=26
        posY=pacY=22
        direction="right"

        positionFantome=1
        posfX=13
        posfY=1

        return pacX, pacY, direction
        return positionFantome, posfX, posfY



    chargetiles(tiles)                                                           #chargement des images

    loop=True
    while loop==True:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                loop=False                                                       #fermeture de la fenetre (croix rouge)

            elif event.type==pygame.KEYDOWN:                                     #une touche a été pressée...laquelle ?

                if event.key==pygame.K_UP:                                       #est-ce la touche UP
                    direction='up'

                elif event.key==pygame.K_DOWN:                                   #est-ce la touche DOWN
                    direction='down'

                elif event.key==pygame.K_LEFT:                                   #est-ce la touche LEFT
                    direction='left'

                elif event.key==pygame.K_RIGHT:                                  #est-ce la touche RIGHT
                    direction='right'

                elif event.key==pygame.K_ESCAPE or event.unicode=='q':           #touche q pour quitter
                    loop=False


        if direction=='up':
            posY=pacY-1                                                          #on deplace le pacman virtuellement
            posX=pacX
            numeroTile=niveau[round(posY)][round(posX)]                          #on regarde le numéro du tile
            print("up",numeroTile,end=':')

            if numeroTile==18 or numeroTile==19 or numeroTile==0:                                  #si le tile est une bille ou un fond noir alors le déplacement est possible
                for i in range(1,32,8):
                    pacY+=(posY-pacY)/i                                          #on monte donc il faut décrémenter pacY
                print("deplacement possible",pacX,pacY)
            else:
                print("deplacement impossible")

        elif direction=='down':
            posY=pacY+1
            posX=pacX
            numeroTile=niveau[round(posY)][round(posX)]
            print("down",numeroTile,end=':')

            if numeroTile==18 or numeroTile==19 or numeroTile==0:
                for i in range(1,32,8):
                    pacY+=(posY-pacY)/i
                print("deplacement possible",pacX,pacY)
            else:
                print("deplacement impossible")

        elif direction=='left':
            posY=pacY
            posX=pacX-1
            numeroTile=niveau[round(posY)][round(posX)]
            print("left",numeroTile,end=':')

            if numeroTile==18 or numeroTile==19 or numeroTile==0:
                for i in range(1,32,8):
                    pacX+=(posX-pacX)/i
                print("deplacement possible",pacX,pacY)
            else:
                print("deplacement impossible")

        elif direction=='right':
            posY=pacY
            posX=pacX+1
            numeroTile=niveau[round(posY)][round(posX)]
            print("right",numeroTile,end=':')

            if numeroTile==18 or numeroTile==19 or numeroTile==0:
                for i in range(1,32,8):
                    pacX+=(posX-pacX)/i
                print("deplacement possible",pacX,pacY)
            else:
                print("deplacement impossible")

        if numeroTile==18:                                                       #si le numero du tile est 18 c'est que l'on est sur une nouvelle bille
            compteurBilles+=10                                                   #alors on incrémente le score
            niveau[round(posY)][round(posX)]=0                                   #et on efface la bille dans le niveau
            print("nouvelle bille")
            coin.play(loops=0, maxtime=0, fade_ms=0)

        if numeroTile==19:
            compteurBilles+=50
            niveau[round(posY)][round(posX)]=0
            print("nouvelle super-bille")
            coin.play(loops=0, maxtime=0, fade_ms=0)

        else:
            print("fond noir")

        if vies>0:
            if pacX==posfX and pacY==posfY:
                posX=pacX=26
                posY=pacY=22
                direction="right"
                vies-=1

                posfX=13
                posfY=1
                positionFantome=1
                frameRateCounterFantome=0
                quack.play(loops=0, maxtime=0, fade_ms=0)
                time.sleep(1)

        elif vies==0:
           gameover()

        if compteurBilles==5730:
            gagne()


        fenetre.fill((255,202,209))                                              #efface la fenetre
        afficheNiveau(niveau)                                                    #affiche le niveau
        affichePac()                                                             #affiche pacman et le score
        deplaceFantome(fantome)                                                  #mettre en commentaire pour desactiver le déplacement du fantome
        touchFantome(pacX, pacY, posfX, posfY)
        afficheScoreEtVies(compteurBilles,vies)
        pygame.display.update()                                                  #mets à jour la fentre graphique
    pygame.quit()

main_menu()

"""
23/12: carte
24/12: collision fantome-pac, début restart niveau et game over
25/12: Keep walking quand touche lachée, déplacements fluides
05/12: ffichage vies et score, animation marche, menu
07/12: son et musique, fin du jeu+restart
08/12: ajout fantomes
"""

def ToDo():
    pass
    #"carte"#
    #"direction"#
    #"déplacements fluides"#
    #"Keep walking"#
    #"restart niveau"#
    "animation mort"#//trop dur snif
    #"animation marche"#
    #"son coincoin"#
    "mange fantomes"
    "ajout fantomes"
    "dessiner un autre fantome parce que moche"
    #"menu et autres écrans"#
    "fantomes qui commencent dans la maison"
    #"fin du jeu"#
    #"accélerer la vitesse de pac parce que là c'est nimp"#